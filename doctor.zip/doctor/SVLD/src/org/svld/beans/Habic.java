/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.svld.beans;

/**
 *
 * @author Rajasekhar
 */
public class Habic {
     private String name;
    private String age;
    private String sex;
    private String refBy;
    private String village;
     private String hbaic;
      private String nonDiaberic;
       private String goodControl;
        private String fairControl;
        private String poorControl;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getRefBy() {
        return refBy;
    }

    public void setRefBy(String refBy) {
        this.refBy = refBy;
    }

    public String getVillage() {
        return village;
    }

    public void setVillage(String village) {
        this.village = village;
    }

    public String getHbaic() {
        return hbaic;
    }

    public void setHbaic(String hbaic) {
        this.hbaic = hbaic;
    }

    public String getNonDiaberic() {
        return nonDiaberic;
    }

    public void setNonDiaberic(String nonDiaberic) {
        this.nonDiaberic = nonDiaberic;
    }

    public String getGoodControl() {
        return goodControl;
    }

    public void setGoodControl(String goodControl) {
        this.goodControl = goodControl;
    }

    public String getFairControl() {
        return fairControl;
    }

    public void setFairControl(String fairControl) {
        this.fairControl = fairControl;
    }

    public String getPoorControl() {
        return poorControl;
    }

    public void setPoorControl(String poorControl) {
        this.poorControl = poorControl;
    }
     
   
        
    
}
