/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.svld.beans;

import java.util.Date;

/**
 *
 * @author Rajasekhar
 */
public class BloodForWidal {
    private String name;
    private String age;
    private String sex;
    private String refBy;
    private String village;
    private String sTyphio;
    private String sTyphih;
    private String widal;
    private String ahbh;
    private Date date;

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getRefBy() {
        return refBy;
    }

    public void setRefBy(String refBy) {
        this.refBy = refBy;
    }

    public String getVillage() {
        return village;
    }

    public void setVillage(String village) {
        this.village = village;
    }
   

    public String getsTyphio() {
        return sTyphio;
    }

    public void setsTyphio(String sTyphio) {
        this.sTyphio = sTyphio;
    }

    public String getsTyphih() {
        return sTyphih;
    }

    public void setsTyphih(String sTyphih) {
        this.sTyphih = sTyphih;
    }

    public String getWidal() {
        return widal;
    }

    public void setWidal(String widal) {
        this.widal = widal;
    }

    public String getAhbh() {
        return ahbh;
    }

    public void setAhbh(String ahbh) {
        this.ahbh = ahbh;
    }
    
    
}
