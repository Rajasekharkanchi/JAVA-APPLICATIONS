/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.svld.beans;

/**
 *
 * @author Rajasekhar
 */
public class Cbp {
    
    private String name;
    private String age;
    private String sex;
    private String refBy;
    private String village;
    private String hemoglobin;
    private String totalwbcCount;
    private String totalrbcCount;
    private String packedcellVolume;
    private String mvc;
    private String mch;
    private String mchc;
    private String nuetrophils;
    private String lymphosytes;
    private String eosinophils;
    private String monacytes;
    private String basophils;
    private String esr1oneandhalfhour;
    private String esronehour;
    private String randomBloodSugar;
 
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getRefBy() {
        return refBy;
    }

    public void setRefBy(String refBy) {
        this.refBy = refBy;
    }

    public String getVillage() {
        return village;
    }

    public void setVillage(String village) {
        this.village = village;
    }

    public String getHemoglobin() {
        return hemoglobin;
    }

    public void setHemoglobin(String hemoglobin) {
        this.hemoglobin = hemoglobin;
    }

    public String getTotalwbcCount() {
        return totalwbcCount;
    }

    public void setTotalwbcCount(String totalwbcCount) {
        this.totalwbcCount = totalwbcCount;
    }

    public String getTotalrbcCount() {
        return totalrbcCount;
    }

    public void setTotalrbcCount(String totalrbcCount) {
        this.totalrbcCount = totalrbcCount;
    }

    public String getPackedcellVolume() {
        return packedcellVolume;
    }

    public void setPackedcellVolume(String packedcellVolume) {
        this.packedcellVolume = packedcellVolume;
    }

    public String getMvc() {
        return mvc;
    }

    public void setMvc(String mvc) {
        this.mvc = mvc;
    }

    public String getMch() {
        return mch;
    }

    public void setMch(String mch) {
        this.mch = mch;
    }

    public String getMchc() {
        return mchc;
    }

    public void setMchc(String mchc) {
        this.mchc = mchc;
    }

    public String getNuetrophils() {
        return nuetrophils;
    }

    public void setNuetrophils(String nuetrophils) {
        this.nuetrophils = nuetrophils;
    }

    public String getLymphosytes() {
        return lymphosytes;
    }

    public void setLymphosytes(String lymphosytes) {
        this.lymphosytes = lymphosytes;
    }

    public String getEosinophils() {
        return eosinophils;
    }

    public void setEosinophils(String eosinophils) {
        this.eosinophils = eosinophils;
    }

    public String getMonacytes() {
        return monacytes;
    }

    public void setMonacytes(String monacytes) {
        this.monacytes = monacytes;
    }

    public String getBasophils() {
        return basophils;
    }

    public void setBasophils(String basophils) {
        this.basophils = basophils;
    }

    public String getEsr1oneandhalfhour() {
        return esr1oneandhalfhour;
    }

    public void setEsr1oneandhalfhour(String esr1oneandhalfhour) {
        this.esr1oneandhalfhour = esr1oneandhalfhour;
    }

    public String getEsronehour() {
        return esronehour;
    }

    public void setEsronehour(String esronehour) {
        this.esronehour = esronehour;
    }

    public String getRandomBloodSugar() {
        return randomBloodSugar;
    }

    public void setRandomBloodSugar(String randomBloodSugar) {
        this.randomBloodSugar = randomBloodSugar;
    }
    
     
    
    
    
    
    
}
