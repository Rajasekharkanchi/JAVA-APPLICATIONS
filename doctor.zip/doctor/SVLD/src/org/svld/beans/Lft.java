/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.svld.beans;


/**
 *
 * @author Rajasekhar
 */
public class Lft {
    
    private String name;
    private String age;
    private String sex;
    private String refBy;
    private String village;

    private String totalBillirubin;
    private String directBillirubin;
    private String indirectBillirubin;
    private String sgot;
    private String sgpt;
    private String alkainPhosphate;
    private String totalProtiens;
    private String albumin;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getRefBy() {
        return refBy;
    }

    public void setRefBy(String refBy) {
        this.refBy = refBy;
    }

    public String getVillage() {
        return village;
    }

    public void setVillage(String village) {
        this.village = village;
    }

    public String getTotalBillirubin() {
        return totalBillirubin;
    }

    public void setTotalBillirubin(String totalBillirubin) {
        this.totalBillirubin = totalBillirubin;
    }

    public String getDirectBillirubin() {
        return directBillirubin;
    }

    public void setDirectBillirubin(String directBillirubin) {
        this.directBillirubin = directBillirubin;
    }

    public String getIndirectBillirubin() {
        return indirectBillirubin;
    }

    public void setIndirectBillirubin(String indirectBillirubin) {
        this.indirectBillirubin = indirectBillirubin;
    }

    public String getSgot() {
        return sgot;
    }

    public void setSgot(String sgot) {
        this.sgot = sgot;
    }

    public String getSgpt() {
        return sgpt;
    }

    public void setSgpt(String sgpt) {
        this.sgpt = sgpt;
    }

    public String getAlkainPhosphate() {
        return alkainPhosphate;
    }

    public void setAlkainPhosphate(String alkainPhosphate) {
        this.alkainPhosphate = alkainPhosphate;
    }

    public String getTotalProtiens() {
        return totalProtiens;
    }

    public void setTotalProtiens(String totalProtiens) {
        this.totalProtiens = totalProtiens;
    }

    public String getAlbumin() {
        return albumin;
    }

    public void setAlbumin(String albumin) {
        this.albumin = albumin;
    }
    
    
    
    
    
}
