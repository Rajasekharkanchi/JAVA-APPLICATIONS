/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.svld.beans;

/**
 *
 * @author Rajasekhar
 */
public class LipidProfile {
    
     private String name;
    private String age;
    private String sex;
    private String refBy;
    private String village;
    private String seremCholestrol;
    private String hdclCholestrol;
    private String ldlCholestrol;
    private String vldlCholestrol;
    private String triglycerides;
    
    

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getRefBy() {
        return refBy;
    }

    public void setRefBy(String refBy) {
        this.refBy = refBy;
    }

    public String getVillage() {
        return village;
    }

    public void setVillage(String village) {
        this.village = village;
    }

    public String getSeremCholestrol() {
        return seremCholestrol;
    }

    public void setSeremCholestrol(String seremCholestrol) {
        this.seremCholestrol = seremCholestrol;
    }

    public String getHdclCholestrol() {
        return hdclCholestrol;
    }

    public void setHdclCholestrol(String hdclCholestrol) {
        this.hdclCholestrol = hdclCholestrol;
    }

    public String getLdlCholestrol() {
        return ldlCholestrol;
    }

    public void setLdlCholestrol(String ldlCholestrol) {
        this.ldlCholestrol = ldlCholestrol;
    }

    public String getVldlCholestrol() {
        return vldlCholestrol;
    }

    public void setVldlCholestrol(String vldlCholestrol) {
        this.vldlCholestrol = vldlCholestrol;
    }

    public String getTriglycerides() {
        return triglycerides;
    }

    public void setTriglycerides(String triglycerides) {
        this.triglycerides = triglycerides;
    }
    
    
    
}
