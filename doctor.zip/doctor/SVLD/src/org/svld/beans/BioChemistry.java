/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.svld.beans;

/**
 *
 * @author Rajasekhar
 */
public class BioChemistry {
    
    private String name;
    private String age;
    private String sex;
    private String refBy;
    private String village;
    private String randomBloodSugar;
    private String bloodUria;
    private String cerumCreatinne;
    private String totalCholestrol;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getRefBy() {
        return refBy;
    }

    public void setRefBy(String refBy) {
        this.refBy = refBy;
    }

    public String getVillage() {
        return village;
    }

    public void setVillage(String village) {
        this.village = village;
    }

    public String getRandomBloodSugar() {
        return randomBloodSugar;
    }

    public void setRandomBloodSugar(String randomBloodSugar) {
        this.randomBloodSugar = randomBloodSugar;
    }

    public String getBloodUria() {
        return bloodUria;
    }

    public void setBloodUria(String bloodUria) {
        this.bloodUria = bloodUria;
    }

    public String getCerumCreatinne() {
        return cerumCreatinne;
    }

    public void setCerumCreatinne(String cerumCreatinne) {
        this.cerumCreatinne = cerumCreatinne;
    }

    public String getTotalCholestrol() {
        return totalCholestrol;
    }

    public void setTotalCholestrol(String totalCholestrol) {
        this.totalCholestrol = totalCholestrol;
    }
     
   
    
}
