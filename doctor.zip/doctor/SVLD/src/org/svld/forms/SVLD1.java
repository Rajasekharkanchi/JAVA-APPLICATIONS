/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.svld.forms;

/**
 *
 * @author Rajasekhar
 */
public class SVLD1 {
    public static void main(String[] args){
        SVLD manager=new SVLD();
        manager.setVisible(true);
    }
}
